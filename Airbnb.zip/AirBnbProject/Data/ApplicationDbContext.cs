﻿using AirBnbProject.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace AirBnbProject.Data
{
    public class AppUser : IdentityUser 
    {
        

        [Required(ErrorMessage = "Age is required")]
        [Range(18, 100, ErrorMessage = "You must be 18 years or older to register")]
        public int Age { get; set; }
        //[Required(ErrorMessage = "Phone number is required")]
        //[RegularExpression(@"^01(0|1|2|5)\d{8}$", ErrorMessage = "Phone number must be a valid Egypt phone number")]
        //public int Phone { get; set; }



    }
    public class ApplicationDbContext : IdentityDbContext<AppUser>
    {
        public DbSet<City> cities { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}