﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AirBnbProject.Data.Migrations
{
    public partial class identity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
