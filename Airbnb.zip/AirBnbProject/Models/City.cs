﻿using System.ComponentModel.DataAnnotations;

namespace AirBnbProject.Models
{
    public class City
    {
        [Key]
        public int CityId { get; set; }
        [Required]
        public string Name { get; set; }
    }
}
